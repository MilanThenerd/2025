Step 1: Make sure the folder structure is as follow

|workspace
|----/Data
     |---p3.2.a
     |---other.txt...
|---ACO.jar

Step 2: run the command 'java -cp ACO.jar ACO'

Step 3: Follow onscreen instructions


