public class City 
{
  int id;
  double x, y;

  public City(int id, double x, double y) 
  {
      this.id = id;
      this.x = x;
      this.y = y;
  }
}