1. Place the jar file in a folder along with the data folder.
2. Run the jar file using "java -jar u04948123.jar"
3. Follow the programs onscreen instructions

4. Note the initial values for SA 
  - intital temp = 1
  - change in temp = 0.999
  - max iterations = 100 000

5. Note the initial values for TS
  - tabu tenure = 10
  - max iterations = 100 000